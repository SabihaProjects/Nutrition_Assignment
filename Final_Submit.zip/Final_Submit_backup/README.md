# Nutritional Data Modelling & Strategic Evidence Synthesis - submission folder

## Q1 - Data cleaning , harmonisation, estimation (fictional dataset from the assignment)
| File | What it is |
|---|---|
| Q1/q1_analysis.py | Reproducible code (Python: pandas,  numpy, matplotlib). `python q1_analysis.py` regenerates every Q1 output |
| Q1/q1_cleaned_dataset.csv | cleaned dataset with QC flags, standardised age/year/construct,inclusion rule, lineage |
| Q1/q1_data_dictionary.csv | Data dictionary + source lineage |
| Q1/q1_harmonised_estimates.csv | pooled estimates (iron, zinc intake) and seperate evidence streams |
| Q1/q1_sensitivity_grid.csv | 54-scenario sensitivity analysis (pooled estimates) |
| Q1/q1_figure_sources_vs_harmonised.png | The one required visual | 
| Q1/q1_Methodological_Note.docx | 2-page methodological note | 

## Q2 - India country dossier and strategy review
| File | What it is |
|---|---|
| Q2/q2_India_Dossier.docx | Country nutrition dossier |
| Q2/q2_Executive_Presentation.pptx \ 5-slide executive_presentation |
| Q2/q2_Executive_Brief.docx | One-page executive synthesis |
| Q2/q2_Source_Inventory.csv | Datasets, years, definitions, URLs, verificatiin notes |
| Q2/q2_calculations.py, q2_derived_estimates.csv | Reproducible derived calculations + figures |

## Review status / before submission (see REVIEW_AND_CORRECTIONS.md for the full list)

- Q1 scripts run successfully and regenerate the outputs. However, uncertainty inputs are assumptions, and pooled estimates are illustrative. The sources have not been age-standardised to a common population/ year; mismatch is represented only by added uncertainty.
- Q2 is **not submission-ready until he source inventory is verified**. The inventory itself says the CNNS primary report and official NFHS fact sheets were not opened, and India-specific modelled estimates
were not extracted. Verify each key figure, definition, confidence interval and URL against primary sources and correct the dossier/brief/slides if needed.
- Do not describe the Q2 evidence gap as proof that no data exits; phrase it as "not verified/assembled in this review."

## AI-use disclosure (required by the assignment)
Prepared with claude (Anthropic), then reviewed and corrected. Q1 numbers come from running q1_analysis.py. Q2 figures were read from the web sources in the inventory;
several came via journal abstracts or secondary summaries (flagged). NOT verified against originals: CNNS National Report text, NFHS-5 official
fact sheet tables, India-specific GBD/GDD/WHO modelled values. **Re-check every number and URL against its source before submitting.**

## Key assumptions to be aware of (Q1)
The PDF gives no sample sizes/CIs. Uncertainty inputs (dietary survey n=250, deff 1.5; model UI +/-10 pp; bias SDs; 1 pp/year drift) are ASSUMPTIONS,
flagged in the data and varied in the sensitivity grid.
